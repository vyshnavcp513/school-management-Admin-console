<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    public function home(){
    
        return view('home');
    }
    public function form(){
        return view('theme.form');
    }
    public function data(Request $request){
        
        dd($request->name);
        
    }
}
