
<?php $__env->startSection('title'); ?>
form page    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('submit')); ?>" method="post">
  <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="name" class="form-label">name</label>
      <input name="name" type="text" class="form-control" id="name" aria-describedby="name" placeholder="Enter your name" required>
      
    </div>
    <div class="form-group">
        <label for="name">Rollnumber</label>
        <input name="roll_number" type="text" class="form-control" id="rollnumber" aria-describedby="rollnumber" placeholder="Enter your rollnumber" required>
        
      </div>
      <div class="form-group">
        <label for="name">Description</label>
        <input name="description" type="text" class="form-control" id="description" aria-describedby="description" placeholder="description" required>
        
      </div>
   
    <button type="submit" class="btn btn-primary">Submit</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\example-app\resources\views/theme/form.blade.php ENDPATH**/ ?>