
<?php $__env->startSection('title'); ?>
teacher form 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('admin.updateTeachers',22)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="form-group">
      <label for="name" class="required form-label">name<small class="text-danger">*</small></label>
      <input type="text" value="<?php echo e($teachers->name); ?>" class="form-control" name="name" aria-describedby="name" placeholder="Enter yor name " required>
    </div>
    <div class="form-group">
      <label for="age">age<small class="text-danger">*</small></label>
      <input type="text" value="<?php echo e($teachers->age); ?>" class="form-control" name="age" placeholder="enter you age" required>
    </div>
    <div class="form-group">
        <label for="qualification">qualification<small class="text-danger">*</small></label>
        <input type="text" value="<?php echo e($teachers->qualification); ?>" class="form-control" name="qualification" placeholder="enter your qualification" required>
      </div>

      <div class="form-group">
        <label for="course">course</label>
        <input type="text" value="<?php echo e($teachers->course); ?>" class="form-control" name="course" placeholder="enter the course">
      </div>
    <button type="submit" class="btn btn-primary">update</button>
  </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('theme.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\example-app\resources\views/teacherseditform.blade.php ENDPATH**/ ?>