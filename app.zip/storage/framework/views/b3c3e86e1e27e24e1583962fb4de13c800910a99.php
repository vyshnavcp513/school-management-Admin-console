
<?php $__env->startSection('title'); ?>
table form
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<table id="example" class="table table-striped" style="width:100%">
    <thead>
        <tr>
            <th style="color: black">Name</th>
            <th style="color: black">Qualification</th>
            <th style="color: black">age</th>
            <th style="color: black">course</th>
            <th>Edit</th>
            <th>Delete</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($teacher->name); ?></td>
            <td><?php echo e($teacher->qualification); ?></td>
            <td><?php echo e($teacher->age); ?></td>
            <td><?php echo e($teacher->course); ?></td>
            <td>
                <a  class="btn btn-primary" href="<?php echo e(route('admin.editTeachers',$teacher->id)); ?>">edit</a>
            </td>
            <td>
                
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($teacher->id); ?>">
                    Delete
                  </button>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
</table>
<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="exampleModal<?php echo e($teacher->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Do you really want to delete this?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <a type="button" class="btn btn-primary" href="<?php echo e(route('admin.deleteTeachers',$teacher->id)); ?>">Delete</a>
        </div>
      </div>
    </div> --}}
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\example-app\resources\views/table.blade.php ENDPATH**/ ?>