
<?php $__env->startSection('title'); ?>
Home Page
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<a type="button" class="btn btn-primary" href="<?php echo e(route('admin.viewCreateTeachers')); ?>">add teacher</a>

<a type="button" class="btn btn-primary" href="<?php echo e(route('admin.viewTeachers')); ?>">View Teachers</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('theme.welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\HP\example-app\resources\views/home.blade.php ENDPATH**/ ?>